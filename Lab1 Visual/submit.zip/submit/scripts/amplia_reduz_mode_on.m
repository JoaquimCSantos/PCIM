%------------------------%
% Código relativo ao 2 b %
%------------------------%

%                        %
im=imzoneplate(dimensao);

[lin,col]=size(im);


